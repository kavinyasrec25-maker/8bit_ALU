module ALU (
    input  wire [7:0] A,
    input  wire [7:0] B,
    input  wire AL0,
    input  wire SUB,
    input  wire XRA,
    input  wire ANA,
    output reg  [7:0] ALU_Out,
    output reg  [1:0] FLAG
);
    reg [8:0] TEMP;

    always @(*) begin
        ALU_Out = 8'b00000000;
        FLAG = 2'b00;
        TEMP = 9'b000000000;

        case ({AL0, SUB, XRA, ANA})
            4'b0000: begin
                TEMP = {1'b0, A} + {1'b0, B};
                ALU_Out = TEMP[7:0];
                FLAG[0] = TEMP[8];
            end
            4'b0001: begin
                ALU_Out = A - B;
                FLAG[0] = (A >= B);
            end
            4'b0100: ALU_Out = A & B;
            4'b0101: ALU_Out = A | B;
            4'b0110: ALU_Out = A ^ B;
            4'b0111: ALU_Out = ~A;
            default: ALU_Out = 8'b00000000;
        endcase

        FLAG[1] = (ALU_Out == 8'b00000000);
    end
endmodule
