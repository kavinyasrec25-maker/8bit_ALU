`timescale 1ns / 1ps
module A_register (
    input wire clk,
    input wire reset,
    input wire load,
    input wire output_en,
    input wire [7:0] bus_in,
    output reg [7:0] a_data,
    output wire [7:0] bus_out
);
    always @(posedge clk) begin
        if (reset)
            a_data <= 8'b00000000;
        else if (load)
            a_data <= bus_in;
    end

    assign bus_out = output_en ? a_data : 8'b00000000;
endmodule
