module instruction_register(
    output reg [7:0] IR,
    input clk,
    input reset,
    input II,
    input [7:0] bus_in
);
    always @(posedge clk) begin
        if (reset == 1)
            IR <= 8'b00000000;
        else if (II)
            IR <= bus_in;
    end
endmodule
