module PC_4bit (
    input clk,
    input reset,
    input load,
    input enable,
    input [3:0] data_in,
    output reg [3:0] PC
);
    always @(posedge clk) begin
        if (reset == 1)
            PC <= 4'b0000;
        else if (load == 1)
            PC <= data_in;
        else if (enable == 1)
            PC <= PC + 4'b0001;
    end
endmodule
