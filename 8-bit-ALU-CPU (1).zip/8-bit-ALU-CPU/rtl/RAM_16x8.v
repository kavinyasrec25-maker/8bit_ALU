module RAM_16x8 (
    input wire clk,
    input wire [3:0] address,
    input wire [7:0] data_in,
    input wire RI,
    input wire RO,
    output reg [7:0] data_out
);
    reg [7:0] memory [0:15];

    always @(posedge clk) begin
        if (RI)
            memory[address] <= data_in;
        if (RO)
            data_out <= memory[address];
    end
endmodule
