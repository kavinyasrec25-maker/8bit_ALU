module MAR_4(
    input clk,
    input reset,
    input load,
    input [3:0] data_in,
    output reg [3:0] MAR
);
    always @(posedge clk) begin
        if (reset)
            MAR <= 4'b0000;
        else if (load)
            MAR <= data_in;
    end
endmodule
