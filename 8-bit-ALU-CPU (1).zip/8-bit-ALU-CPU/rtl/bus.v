`timescale 1ns / 1ps
module bus(
    input wire [7:0] pc_data,
    input wire [7:0] mar_data,
    input wire [7:0] ram_data,
    input wire [7:0] a_data,
    input wire [7:0] b_data,
    input wire [7:0] alu_data,
    input wire [7:0] ir_data,
    input wire [7:0] out_data,
    input wire [3:0] bus_select,
    output reg [7:0] bus
);
    parameter PC  = 4'b0000,
              MAR = 4'b0001,
              RAM = 4'b0010,
              A   = 4'b0011,
              B   = 4'b0100,
              ALU = 4'b0101,
              IR  = 4'b0110,
              OUT = 4'b0111;

    always @(*) begin
        case (bus_select)
            PC:  bus = pc_data;
            MAR: bus = mar_data;
            RAM: bus = ram_data;
            A:   bus = a_data;
            B:   bus = b_data;
            ALU: bus = alu_data;
            IR:  bus = ir_data;
            OUT: bus = out_data;
            default: bus = 8'b00000000;
        endcase
    end
endmodule
