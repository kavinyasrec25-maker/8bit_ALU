module B_register (
    input clk,
    input reset,
    input load_B,
    input [7:0] bus_in,
    output reg [7:0] B
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            B <= 8'b00000000;
        else if (load_B)
            B <= bus_in;
    end
endmodule
