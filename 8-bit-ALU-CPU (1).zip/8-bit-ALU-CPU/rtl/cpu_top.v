`timescale 1ns / 1ps

module cpu_top (
    input  wire       clk,
    input  wire       reset,
    output wire [7:0] OUT,
    output wire       HLT
);
    wire [7:0] data_bus;
    wire [3:0] pc_value, mar_value;
    wire [7:0] ram_data, ir_value;
    wire [7:0] a_value, a_bus_out, b_value;
    wire [7:0] alu_result, out_value;
    wire [1:0] alu_flags;
    wire [3:0] bus_select;

    wire MI, CL, CE;
    wire II, AI, BI, OI;
    wire RI, FE;
    wire AL0, SUB, XRA, ANA;

    PC_4bit PC_inst (
        .clk(clk), .reset(reset), .load(CL), .enable(CE),
        .data_in(data_bus[3:0]), .PC(pc_value)
    );

    MAR_4 MAR_inst (
        .clk(clk), .reset(reset), .load(MI),
        .data_in(data_bus[3:0]), .MAR(mar_value)
    );

    RAM_16x8 RAM_inst (
        .clk(clk), .address(mar_value), .data_in(data_bus),
        .RI(RI), .RO(1'b1), .data_out(ram_data)
    );

    instruction_register IR_inst (
        .IR(ir_value), .clk(clk), .reset(reset),
        .II(II), .bus_in(data_bus)
    );

    A_register A_inst (
        .clk(clk), .reset(reset), .load(AI), .output_en(1'b1),
        .bus_in(data_bus), .a_data(a_value), .bus_out(a_bus_out)
    );

    B_register B_inst (
        .clk(clk), .reset(reset), .load_B(BI),
        .bus_in(data_bus), .B(b_value)
    );

    // The ALU module provided in this project is named ALU.
    ALU ALU_inst (
        .A(a_value), .B(b_value), .AL0(AL0), .SUB(SUB),
        .XRA(XRA), .ANA(ANA), .ALU_Out(alu_result), .FLAG(alu_flags)
    );

    Output_register OUT_inst (
        .clk(clk), .reset(reset), .load_OUT(OI),
        .bus_in(data_bus), .OUT(out_value)
    );

    assign OUT = out_value;

    bus BUS_inst (
        .pc_data({4'b0000, pc_value}),
        .mar_data({4'b0000, mar_value}),
        .ram_data(ram_data), .a_data(a_bus_out), .b_data(b_value),
        .alu_data(alu_result), .ir_data(ir_value), .out_data(out_value),
        .bus_select(bus_select), .bus(data_bus)
    );

    control_unit CU_inst (
        .clk(clk), .reset(reset), .IR(ir_value), .bus_select(bus_select),
        .MI(MI), .CL(CL), .CE(CE), .II(II), .AI(AI), .BI(BI),
        .OI(OI), .RI(RI), .FE(FE), .AL0(AL0), .SUB(SUB),
        .XRA(XRA), .ANA(ANA), .HLT(HLT)
    );
endmodule
