`timescale 1ns / 1ps
module Output_register (
    input wire clk,
    input wire reset,
    input wire load_OUT,
    input wire [7:0] bus_in,
    output reg [7:0] OUT
);
    always @(posedge clk or posedge reset) begin
        if (reset)
            OUT <= 8'b00000000;
        else if (load_OUT)
            OUT <= bus_in;
    end
endmodule
