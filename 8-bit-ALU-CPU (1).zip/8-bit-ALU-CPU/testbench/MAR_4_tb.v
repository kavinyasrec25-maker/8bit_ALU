`timescale 1ns / 1ps
module MAR_4_tb;
    reg clk, reset, load;
    reg [3:0] data_in;
    wire [3:0] MAR;

    MAR_4 uut (
        .clk(clk), .reset(reset), .load(load),
        .data_in(data_in), .MAR(MAR)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0; reset = 0; load = 0; data_in = 4'b0000;
        reset = 1; #10;
        reset = 0;
        data_in = 4'b0101; load = 1; #10;
        load = 0;
        data_in = 4'b1010; load = 1; #10;
        load = 0; #10;
        $finish;
    end
endmodule
