`timescale 1ns / 1ps
module PC_4bit_tb;
    reg clk, reset, load, enable;
    reg [3:0] data_in;
    wire [3:0] PC;

    PC_4bit uut (
        .clk(clk), .reset(reset), .load(load), .enable(enable),
        .data_in(data_in), .PC(PC)
    );

    always #5 clk = ~clk;

    initial begin
        clk = 0; reset = 0; load = 0; enable = 0; data_in = 4'b0000;
        reset = 1; #10;
        reset = 0;
        enable = 1; #30;
        enable = 0;
        data_in = 4'b1010; load = 1; #10;
        load = 0;
        enable = 1; #20;
        enable = 0;
        #10;
        $finish;
    end

    initial begin
        $monitor("time=%0t reset=%b load=%b enable=%b data_in=%h PC=%h",
                 $time, reset, load, enable, data_in, PC);
    end
endmodule
