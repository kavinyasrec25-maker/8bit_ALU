`timescale 1ns/1ps
module ALU8_tb;
    reg [7:0] A;
    reg [7:0] B;
    reg AL0, SUB, XRA, ANA;
    wire [7:0] ALU_Out;
    wire [1:0] FLAG;

    // Corrected to match the design module name ALU.
    ALU uut (
        .A(A), .B(B), .AL0(AL0), .SUB(SUB), .XRA(XRA), .ANA(ANA),
        .ALU_Out(ALU_Out), .FLAG(FLAG)
    );

    initial begin
        $monitor("Time=%0t | A=%h | B=%h | Control=%b%b%b%b | ALU_Out=%h | Zero=%b | Carry=%b",
                 $time, A, B, AL0, SUB, XRA, ANA, ALU_Out, FLAG[1], FLAG[0]);

        A = 8'd10;  B = 8'd20;  {AL0,SUB,XRA,ANA}=4'b0000; #10;
        A = 8'd200; B = 8'd100; {AL0,SUB,XRA,ANA}=4'b0000; #10;
        A = 8'd50;  B = 8'd20;  {AL0,SUB,XRA,ANA}=4'b0001; #10;
        A = 8'd10;  B = 8'd20;  {AL0,SUB,XRA,ANA}=4'b0001; #10;
        A = 8'hF0;  B = 8'h0F;  {AL0,SUB,XRA,ANA}=4'b0100; #10;
        A = 8'hF0;  B = 8'h0F;  {AL0,SUB,XRA,ANA}=4'b0101; #10;
        A = 8'hAA;  B = 8'hFF;  {AL0,SUB,XRA,ANA}=4'b0110; #10;
        A = 8'h55;  B = 8'h00;  {AL0,SUB,XRA,ANA}=4'b0111; #10;
        A = 8'd25;  B = 8'd25;  {AL0,SUB,XRA,ANA}=4'b0001; #10;
        $finish;
    end
endmodule
