`timescale 1ns / 1ps
module bus_tb;
    reg [7:0] pc_data, mar_data, ram_data, a_data;
    reg [7:0] b_data, alu_data, ir_data, out_data;
    reg [3:0] bus_select;
    wire [7:0] bus;

    bus uut (
        .pc_data(pc_data), .mar_data(mar_data), .ram_data(ram_data),
        .a_data(a_data), .b_data(b_data), .alu_data(alu_data),
        .ir_data(ir_data), .out_data(out_data),
        .bus_select(bus_select), .bus(bus)
    );

    initial begin
        pc_data=8'b00010010; mar_data=8'b00000101;
        ram_data=8'b10101010; a_data=8'b00110011;
        b_data=8'b01010101; alu_data=8'b11110000;
        ir_data=8'b11001100; out_data=8'b10011001;

        bus_select=4'b0000; #10;
        bus_select=4'b0001; #10;
        bus_select=4'b0010; #10;
        bus_select=4'b0011; #10;
        bus_select=4'b0100; #10;
        bus_select=4'b0101; #10;
        bus_select=4'b0110; #10;
        bus_select=4'b0111; #10;
        bus_select=4'b1111; #10;
        $finish;
    end
endmodule
